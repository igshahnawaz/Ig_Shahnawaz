export const hollyData = [
  {
    id: "hell-hole-2024",
    homeSrc:
      "https://i.pinimg.com/736x/1e/cc/4e/1ecc4eee5a3450090ed98d1a405f4ef6.jpg",
    homeFirstTitle:
      "Hell Hole 2024 Movie AMZN WebRip English ESub 480p 720p 1080p",
    homeTitle: "Hell Hole",
    homeQuality: "WebRip",
    homeDownload: "Download Now",
    homeMore: "...more",
    homeYear: "2024",
    homeLength: "92 min",
    homeDetails:
      "Far away, in the desolate Serbian wilderness, a U.S.-led fracking crew uncover a dormant monster gestating inside a centuries-old French soldier. Now awakened and exposed in its most dangerously fragile state, it tears through the men on the grounds in search of a new womb.",
    homeDirector: "John Adams, Toby Poser",
    homeStar:
      "	Aleksandar Trmcic, Anders Hove, John Adams, Max Portman, Olivera Peruničić, Petar Arsić, Toby Poser",
    homeLang: "English",
    homeSubs: "English",
    homeGenre: "Horror",
    homeCat: "hollywood-english-movies",
    home480p: "480p",
    home720p: "720p",
    home1080p: "1080p",
    home1440p: "1440p",
    home2160p: "2160p",
  },
];
