export const koreanHindiData = [
  {
    id: "all-of-us-are-dead-2022",
    homeSrc:
      "https://i.pinimg.com/736x/96/83/a8/9683a8f98b4dc21687e348c3aa68defd.jpg",
    homeFirstTitle:
      "All of Us Are Dead S01 2022 NF Web Series WebRip Dual Audio Hindi Eng All Episodes 480p 720p 1080p ",
    homeTitle: "All Of Us Are Dead",
    homeQuality: "WebRip",
    homeDownload: "Download Now",
    homeMore: "...more",
    homeYear: "2022",
    homeLength: "61 min",
    homeDetails:
      " A science teacher's experiment gone wrong unleashes the virus, spreading chaos throughout the city. The students, struggling to reach safety, must band together, relying on their wits and courage to navigate the increasingly dangerous situation",
    homeDirector: " Chun Sung-il, JQ Lee",
    homeStar:
      "Akram Udaas, B.N. Sharma, Diljit Dosanjh, Jaswinder Bhalla, Neeru Bajwa, Rana Ranbir",
    homeLang: "Hindi, English",
    homeSubs: "English",
    homeGenre: "Horror, Zombie apocalypse, Thriller, Action",
    homeCat: "korean-drama-hindi-dubbed",
    home480p: "480p",
    home720p: "720p",
    home1080p: "1080p",
    home1440p: "1440p",
    home2160p: "2160p",
  },
];