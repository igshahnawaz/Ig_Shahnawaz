export const hollyHindiData = [
  {
    id: "a-knight's-war-2025",
    homeSrc:
      "https://i.pinimg.com/736x/68/42/ae/6842ae97eaa8e56fe097d275455bf66a.jpg",
    homeFirstTitle:
      "A Knight’s War (2025) Hindi Dubbed (Voice Over) WebRip 720p HD Hindi-Subs",
    homeTitle: "A Knight's War",
    homeQuality: "Web-Dl",
    homeDownload: "Download Now",
    homeMore: "...more",
    homeYear: "2025",
    homeLength: "105 min",
    homeDetails:
      "A fearless knight braves a deadly realm to save the Chosen One's soul. Facing witches, demons, and brutal foes, he discovers her return could ignite chaos and doom humanity.",
    homeDirector: "Matthew Ninaber",
    homeStar: "Jeremy Ninaber, Kristen Kaster, Matthew Ninaber,",
    homeLang: "Hindi, English",
    homeSubs: "English",
    homeGenre: "Dark Fantasy",
    homeCat: "hollywood-hindi-dubbed-movies",
    home480p: "480p",
    home720p: "720p",
    home1080p: "1080p",
    home1440p: "1440p",
    home2160p: "2160p",
  },
  {
    id: "captain-america-brave-new-world-2025",
    homeSrc:
      "https://i.pinimg.com/736x/34/ff/7e/34ff7e8ef223b1eea18e5c1b4325cc45.jpg",
    homeFirstTitle:
      "Captain America: Brave New World (2025) Hindi Dubbed 480p, 720p & 1080p",
    homeTitle: "Captain America: Brave New World",
    homeQuality: "WebRip",
    homeDownload: "Download Now",
    homeMore: "...more",
    homeYear: "2025",
    homeLength: "118 min",
    homeDetails:
      "The Film Is Based On The Marvel Comics Character “Sam Wilson/Captain America,” And It Is Intended To Be The Fourth Installment In The “Captain America Film Series,” A Continuation Of The 2021 Disney+ Miniseries “The Falcon And The Winter Soldier,” And The Part Of Phase Five & 35th Film In The “Marvel Cinematic Universe” (MCU) !!",
    homeDirector: "Julius Onah",
    homeStar: "Anthony Mackie, Danny Ramirez, Shira Haas,",
    homeLang: "Hindi, English",
    homeSubs: "English",
    homeGenre: "Action, Sci-fi",
    homeCat: "hollywood-hindi-dubbed-movies",
    home480p: "480p",
    home720p: "720p",
    home1080p: "1080p",
    home1440p: "1440p",
    home2160p: "2160p",
  },
];
