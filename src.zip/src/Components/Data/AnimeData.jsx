export const animeData = [
  {
    id: "attack-on-titan-season-1",
    homeSrc:
      "https://i.pinimg.com/736x/67/b6/90/67b690140f09b858dd942c7a35e434e2.jpg",
    homeFirstTitle:
      "Attack on Titan S01 2013 Web Series AMZN WebRip Hindi English Japanese All Episodes 480p 720p 1080p ",
    homeTitle: "Attack On Titan Season 1",
    homeQuality: "WebRip",
    homeDownload: "Download Now",
    homeMore: "...more",
    homeYear: "2013",
    homeLength: "24 min",
    homeDetails:
      "Many years ago, the last remnants of humanity were forced to retreat behind the towering walls of a fortified city to escape the massive, man-eating Titans that roamed the land outside their fortress. Only the heroic members of the Scouting Legion dared to stray beyond the safety of the walls – but even those brave warriors seldom returned alive. Those within the city clung to the illusion of a peaceful existence until the day that dream was shattered, and their slim chance at survival was reduced to one horrifying choice: kill – or be devoured!",
    homeDirector: "Tetsurō Araki",
    homeStar: "Ayane Sakura, Hiro Shimono, Kisho Taniyama, Marina Inoue",
    homeLang: "Hindi, English, Japanese",
    homeSubs: "English",
    homeGenre: "Action",
    homeCat: "anime-hindi-dubbed",
    home480p: "480p",
    home720p: "720p",
    home1080p: "1080p",
  },
];
