export const webSeriesData = [
  {
    id: "mirzapur-season-3-2024",
    homeSrc:
      "https://i.pinimg.com/736x/b4/98/25/b49825a86f0c90a47333a8ea338380d1.jpg",
    homeFirstTitle:
      "Mirzapur S03 2024 AMZN Web Series Hindi WebRip All Episodes 480p 720p 1080p 2160p ",
    homeTitle: "Mirzapur Season 3",
    homeQuality: "WebRip",
    homeDownload: "Download Now",
    homeMore: "...more",
    homeYear: "2024",
    homeLength: "45 min",
    homeDetails:
      "In Mirzapur season 3, Guddu Pandit and Golu Gupta attempt to establish their rule over Mirzapur while facing challenges from Sharad Shukla and a recovering Kaleen Bhaiya. The season explores Guddu's descent into madness, his alliance with Golu, and the political machinations of Madhuri Yadav, the new Chief Minister, as she tries to establish a state. Kaleen Bhaiya's slow recovery and eventual return add another layer of conflict as he seeks to reclaim his power. ",
    homeDirector: " Karan Anshuman, Puneet Krishna, Vineet Krishnan",
    homeStar:
      "Ali Fazal, Divyendu Sharma, Harshita Gaur, Kulbhushan Kharbanda, Pankaj Tripathi",
    homeLang: "Hindi",
    homeSubs: "English",
    homeGenre: "Crime, Thriller, Action",
    homeCat: "web-series",
    home480p: "480p",
    home720p: "720p",
    home1080p: "1080p",
    home1440p: "1440p",
    home2160p: "2160p",
  },
];
