export const punjabiData = [
  {
    id: "jatt-and-juliet-3-2024",
    homeSrc:
      "https://i.pinimg.com/736x/3a/42/22/3a4222fa8a8d70092c017e3ccce5d717.jpg",
    homeFirstTitle:
      "Jatt And Juliet 3 – 2024 Movie Punjabi AMZN WebRip ESub 480p 720p 1080p 2160p ",
    homeTitle: "Jatt And Juliet 3",
    homeQuality: "WebRip",
    homeDownload: "Download Now",
    homeMore: "...more",
    homeYear: "2024",
    homeLength: "135 min",
    homeDetails:
      "A police officer aspires to marry his well-off boss and joins her on a trip to the UK to track down a woman.",
    homeDirector: "Jagdeep Sidhu",
    homeStar:
      "Akram Udaas, B.N. Sharma, Diljit Dosanjh, Jaswinder Bhalla, Neeru Bajwa, Rana Ranbir",
    homeLang: "Punjabi",
    homeSubs: "English",
    homeGenre: "Comedy",
    homeCat: "punjabi-movies",
    home480p: "480p",
    home720p: "720p",
    home1080p: "1080p",
    home1440p: "1440p",
    home2160p: "2160p",
  },
];
