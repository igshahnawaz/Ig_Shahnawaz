import { returnPaginationRange } from "../Utils/appUtils";
import React from "react";
import "../Css/Pagination.scss";
// import "bootstrap/dist/css/bootstrap.css";
export default function Pagination(props) {
  let array = returnPaginationRange(
    props.totalPage,
    props.page,
    props.limit,
    props.siblings
  );
  return (
    <div className="pagination pagination-lg justify-content-end">
      <div className="list-item">
        <button
          className="page-link"
          onClick={() => props.onPageChange("Previous")}
          style={{ display: `${props.page <= 1 ? "none" : "block"}` }}
        >
          Previous
        </button>
      </div>
      {array.map((value, i) => {
        if (value === props.page) {
          return (
            <div key={i} className="list-item active ">
              <button
                className="page-link"
                onClick={() => props.onPageChange(value)}
              >
                {value}
              </button>
            </div>
          );
        } else {
          return (
            <div key={i} className="list-item">
              <button
                className="page-link"
                onClick={() => props.onPageChange(value)}
              >
                {value}
              </button>
            </div>
          );
        }
      })}
      <div className="list-item">
        <button
          className="page-link"
          onClick={() => props.onPageChange("Next")}
          style={{ display: `${props.totalPage >= 1 ? "none" : "block"}` }}
        >
          Next
        </button>
      </div>
    </div>
  );
}
