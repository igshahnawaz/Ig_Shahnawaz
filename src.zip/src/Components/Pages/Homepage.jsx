import Footer from "./Footer";
import Header from "./Header";
import "../Css/HomeCard.css";
import "../Css/Pagination.scss";
import "../Css/HomeCard.css";
import "../Css/Header.css";
import "../Css/Footer.css";
import "bootstrap/dist/css/bootstrap.css";
import Scalable from "./Scalable";
import Sidebar from "./Sidebar";
import { homePageData, homePageLength } from "../Data/HomeCardData";
import React, { useState } from "react";
import HomeCard from "../Pages/HomeCard.jsx";
import Pagination from "./Pagination";

function Homepage() {
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  let totalPage = Math.ceil(homePageLength() / limit);
  function handlePageChange(value) {
    if (value === "Next") {
      setPage(page + 1);
      console.log(1);
    } else if (value === "Previous") {
      setPage(page - 1);
    } else {
      setPage(value);
    }
  }
  return (
    <div className="Homepage">
      <Header />
      <Sidebar />
      <Scalable />
      <HomeCard homeCards={homePageData(page, limit)} />
      <Pagination
        totalPage={totalPage}
        page={page}
        limit={limit}
        siblings={1}
        onPageChange={handlePageChange}
      />
      <Footer />
    </div>
  );
}

export default Homepage;
